Ver guía del mensaje anterior. Pasos rápidos: configurar .env, crear tablas y bucket en Supabase, deploy a Vercel, pegar el <script> en Custom Liquid del theme.
