Escribe un libro (~200 páginas) desde un BRIEF. Primero outline (JSON), luego capítulos (JSON). Devuelve JSON válido.
